package com.test.entity;

public class TestDMPRequest {

}
