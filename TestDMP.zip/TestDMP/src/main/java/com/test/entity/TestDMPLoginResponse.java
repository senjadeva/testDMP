package com.test.entity;

public class TestDMPLoginResponse {
	
	private Boolean isMatch;

	public Boolean getIsMatch() {
		return isMatch;
	}

	public void setIsMatch(Boolean isMatch) {
		this.isMatch = isMatch;
	}

}
