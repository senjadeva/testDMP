# Changelog
All notable changes to this project will be documented in this file.

## [1.1.0] - 2023-03-19

### Added

### Changed

### Removed

### Fixed